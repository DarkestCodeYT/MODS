package net.mcreator.shade.procedures;

import java.util.Map;

public class GrimoireEntitySwingsItemProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {

	}
}
